/*
 * app_lcd.h
 *
 *  Created on: Feb 2, 2025
 *      Author: munir
 */

#ifndef INC_APP_LCD_H_
#define INC_APP_LCD_H_


void lcd_init (void);
void lcd_set_backlight (float brighness);

#endif /* INC_APP_LCD_H_ */
